package com.practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverInfo {
	
	private WebDriver webdriver;

	public DriverInfo() {
		webdriver = new ChromeDriver();
	}
	
	public void openURL(String url) {
		 webdriver.get(url);
		
	}
	
	

}
